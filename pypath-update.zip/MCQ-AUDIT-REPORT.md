# PyPath MCQ audit (Levels 1-6)

Repo: paularnav49-cloud/Pypath0. The project is in `PyPath/`: `PyPath/content/build_course.py` generates `PyPath/app/src/main/assets/course/course.json` (index only) plus one quiz/lesson file per level in `PyPath/app/src/main/assets/course/levels/l1.json` ... `l7.json`. All seven level files and the whole build script were read. Level 7 (7.1 Final Project) and the level bonus projects (n.P) have no lesson+quiz, so they are not part of this audit.

Answers were checked by running every code snippet under Python 3.11.15 (the script's own `check=` tests plus extra runs of every distractor claim and every fix).

## 1. Summary

- Questions audited: **125** (25 sub-levels, Levels 1-6)
- IN SCOPE: **120**
- REVIEW: **1**
- OUT OF SCOPE: **4**
- FUTURE: **0**
- Wrong-answer or ambiguous questions: **4** (no wrong correctIndex was found; l4s5q6 and l6s3q7 each had a second working option, l6s2q5 had a false explanation, l2s3q3 had an ambiguous correct option)
- Questions changed: **42** (4 OUT OF SCOPE fixes, the rest fix hidden prerequisites in options, give-away options, weak explanations, or answer-position balance)
- FUTURE as a question label: 0. One explanation referred to a FUTURE topic (l2s2q1 mentioned elif) and one question used FUTURE terms as distractors (l4s2q2). Both are fixed.

## 2. Audit table

Hidden-prerequisite findings (check 2) and option/wording findings (checks 4-5) are in the Problem column. A dash means the question passed all checks.

| Question id | Sub-level | Label | Evidence or missing concept | Problem | Action |
|---|---|---|---|---|---|
| l1s1q1 | 1.1 | IN SCOPE | 1.1 'Your first program' explain: print shows something on the screen | Distractors 'Takes user input' and 'Creates a variable' use terms from 1.2/1.4 (not yet taught); explanation does not say why wrong options are wrong | rewritten (distractors + explanation) |
| l1s1q2 | 1.1 | IN SCOPE | 1.1 'Printing more' code print(2 + 3) -> 5 | Explanation does not address the "5" (quoted) distractor | rewritten (explanation) |
| l1s1q3 | 1.1 | IN SCOPE | 1.1 'Comments' text: lines starting with # are comments | Explanation does not address //, --, /* | rewritten (explanation) |
| l1s1q4 | 1.1 | IN SCOPE | 1.1 'Printing more' tip: Python reads code line by line from the top; 'Meet Python' key point | Explanation only restates the answer | rewritten (explanation) |
| l1s2q1 | 1.2 | IN SCOPE | 1.2 'What is a variable?' text: create one with = | Distractor city == "Pune" uses == (not taught until 2.1); explanation weak | rewritten (one distractor + explanation) |
| l1s2q2 | 1.2 | IN SCOPE | 1.2 'Changing a value' code score = 10 / 15 | - | keep |
| l1s2q3 | 1.2 | IN SCOPE | 1.2 'Naming rules' bullets | - | keep |
| l1s2q4 | 1.2 | IN SCOPE | 1.2 'Using variables together' code apples + oranges | Explanation does not address 'a + b' or '34' | rewritten (explanation) |
| l1s3q1 | 1.3 | IN SCOPE | 1.3 'Every value has a type' bullet: float - decimal numbers | Explanation only restates the answer | rewritten (explanation) |
| l1s3q2 | 1.3 | IN SCOPE | 1.3 'Why types matter' code print("2" + "3") | - | keep |
| l1s3q3 | 1.3 | IN SCOPE | 1.3 'Every value has a type' bullet: bool - True or False | Option 'yes' uses single quotes, never taught in Levels 1-2 | rewritten (one distractor + explanation) |
| l1s3q4 | 1.3 | IN SCOPE | 1.3 'Converting types' code int(age_text) | Explanation does not address str()/float()/type() | rewritten (explanation) |
| l1s4q1 | 1.4 | IN SCOPE | 1.4 'Input is always text' | - | keep |
| l1s4q2 | 1.4 | IN SCOPE | 1.4 'Doing maths with input' code int(input(...)) | Explanation does not address input(int()) | rewritten (explanation) |
| l1s4q3 | 1.4 | IN SCOPE | 1.4 'Formatting output' f-string code | - | keep |
| l1s4q4 | 1.4 | IN SCOPE | 1.4 'Getting input' explain: text inside input() is the question shown | Explanation uses undefined term 'prompt' | rewritten (explanation) |
| l2s1q1 | 2.1 | IN SCOPE | 2.1 'Asking questions' bullet >= greater or equal | - | keep |
| l2s1q2 | 2.1 | IN SCOPE | 2.1 'Try them' key point: == compares, = stores | - | keep |
| l2s1q3 | 2.1 | IN SCOPE | 2.1 'Asking questions' bullet < less than | Quiz balance: [0,1,1] puts 2 of 3 answers at position 1 | reordered |
| l2s2q1 | 2.2 | IN SCOPE | 2.2 'The if statement' explain: colon at end of the if line | Explanation mentions elif (taught in 2.3: FUTURE); quiz balance [1,1,1] (three in a row) | reordered + explanation rewritten |
| l2s2q2 | 2.2 | IN SCOPE | 2.2 'Adding else' code | - | keep |
| l2s2q3 | 2.2 | IN SCOPE | 2.2 'Indentation matters' text | Quiz balance [1,1,1]; explanation does not address braces/end | reordered + explanation rewritten |
| l2s3q1 | 2.3 | IN SCOPE | 2.3 'More than two choices' text: elif (short for else if) | Silly distractor 'elevate if'; quiz balance [0,1,1] | rewritten (one distractor + explanation) |
| l2s3q2 | 2.3 | IN SCOPE | 2.3 'More than two choices' code (marks/grade) | - | keep |
| l2s3q3 | 2.3 | IN SCOPE | 2.3 'Order matters' key point: runs only the first one that is True | Correct option 'Exactly one at most' is awkward and ambiguous (exactly one vs at most one), and much longer than the others; 'None ever' is silly | rewritten |
| l3s1q1 | 3.1 | OUT OF SCOPE | MISSING: 3.1 never says range(n) starts at 0 ('range(5) means do this 5 times' only); only range(1,6) and range(0,10,2) show values | Tests that range(3) starts at 0, which 3.1 does not teach | replaced (step range(0, 9, 3), taught on 'Counting with range()') |
| l3s1q2 | 3.1 | IN SCOPE | 3.1 'Counting with range()' range(1, 6) explain | - | keep |
| l3s1q3 | 3.1 | IN SCOPE | 3.1 'Your first for loop' explain: line ends with a colon | - | keep |
| l3s1q4 | 3.1 | IN SCOPE | 3.1 'Adding up with a loop' Common mistake: range(1, 6) to include 5 | Prompt says 'prints' but shows no print line; blank was inside the prompt | rewritten (prompt + code snippet) |
| l3s1q5 | 3.1 | IN SCOPE | 3.1 'Adding up with a loop' total += n | - | keep |
| l3s2q1 | 3.2 | IN SCOPE | 3.2 'Repeat while something is true' code | - | keep |
| l3s2q2 | 3.2 | IN SCOPE | 3.2 'Repeat while something is true' text | - | keep |
| l3s2q3 | 3.2 | IN SCOPE | 3.2 'Infinite loops' Common mistake | - | keep |
| l3s2q4 | 3.2 | IN SCOPE | 3.2 'A countdown' n -= 1 | - | keep |
| l3s2q5 | 3.2 | IN SCOPE | 3.2 'A countdown' n -= 1 pattern | - | keep |
| l3s2q6 | 3.2 | IN SCOPE | 3.2 page 1 text: checks the condition before every repeat | - | keep |
| l3s3q1 | 3.3 | OUT OF SCOPE | MISSING: relies on range(5) starting at 0, not taught in 3.1-3.3 (3.3 examples use range(1, 10) / range(1, 7)) | Hidden prerequisite: range(n) starts at 0 | rewritten (range(1, 6)) |
| l3s3q2 | 3.3 | OUT OF SCOPE | MISSING: relies on range(4) starting at 0, not taught in 3.1-3.3 | Hidden prerequisite: range(n) starts at 0 | rewritten (range(1, 5)) |
| l3s3q3 | 3.3 | IN SCOPE | 3.3 'Skipping with continue' + key point | - | keep |
| l3s3q4 | 3.3 | IN SCOPE | 3.3 'Skipping with continue' text: % gives the remainder | - | keep |
| l3s4q1 | 3.4 | IN SCOPE | 3.4 key point: outer repeats x inner repeats | - | keep |
| l3s4q2 | 3.4 | IN SCOPE | 3.4 'Drawing a triangle' code | - | keep |
| l3s4q3 | 3.4 | IN SCOPE | 3.4 'Staying on one line' text | - | keep |
| l3s4q4 | 3.4 | IN SCOPE | 3.4 'Repeating text with *' | - | keep |
| l3s4q5 | 3.4 | IN SCOPE | 3.4 'Indentation decides everything' + Common mistake | - | keep |
| l3s4q6 | 3.4 | IN SCOPE | 3.4 'A loop inside a loop' (range(2) shown as 0, 1) | - | keep |
| l3s4q7 | 3.4 | IN SCOPE | 3.4 'Staying on one line' end=" " | Distractor sep=" " and its explanation use sep, never taught in any lesson | rewritten (distractor + explanation) |
| l3s4q8 | 3.4 | IN SCOPE | 3.4 'A loop inside a loop' text | - | keep |
| l4s1q1 | 4.1 | IN SCOPE | 4.1 'Defining and calling' explain: def starts a function definition | Prompt uses the term 'keyword', not defined in 4.1 | rewritten (prompt wording) |
| l4s1q2 | 4.1 | IN SCOPE | 4.1 'Define first, then call' text | - | keep |
| l4s1q3 | 4.1 | IN SCOPE | 4.1 'Defining and calling' explain: the colon : is required | - | keep |
| l4s1q4 | 4.1 | IN SCOPE | 4.1 'Defining and calling' greet() twice | - | keep |
| l4s1q5 | 4.1 | IN SCOPE | 4.1 'Define first, then call' text | - | keep |
| l4s2q1 | 4.2 | IN SCOPE | 4.2 'Passing information in' | - | keep |
| l4s2q2 | 4.2 | IN SCOPE | 4.2 'Parameters vs arguments' bullets | Distractors 'Return values' (4.3) and 'Global variables' (4.5) are terms not yet defined | rewritten (distractors + explanation) |
| l4s2q3 | 4.2 | IN SCOPE | 4.2 'More than one parameter' values matched in order | - | keep |
| l4s3q1 | 4.3 | IN SCOPE | 4.3 'Sending a value back' | - | keep |
| l4s3q2 | 4.3 | IN SCOPE | 4.3 'print vs return' | - | keep |
| l4s3q3 | 4.3 | IN SCOPE | 4.3 'Sending a value back' + 'return ends the function' | Correct option much longer than the distractors (1.6x); uses 'caller', not used in 4.3 | rewritten (options) |
| l4s3q4 | 4.3 | IN SCOPE | 4.3 'Forgetting return' + Common mistake | - | keep |
| l4s3q5 | 4.3 | IN SCOPE | 4.3 'return ends the function' | - | keep |
| l4s3q6 | 4.3 | IN SCOPE | 4.3 'Sending a value back' | - | keep |
| l4s4q1 | 4.4 | IN SCOPE | 4.4 'Default values' | - | keep |
| l4s4q2 | 4.4 | IN SCOPE | 4.4 'Keyword arguments' | - | keep |
| l4s4q3 | 4.4 | IN SCOPE | 4.4 'Default values' Common mistake (SyntaxError) | - | keep |
| l4s4q4 | 4.4 | IN SCOPE | 4.4 'Default values' text | Correct option much longer than the distractors (1.6x) | rewritten (distractors) |
| l4s5q1 | 4.5 | IN SCOPE | 4.5 'Local variables' NameError example | Correct option 3x longer and the only one with a reason | rewritten (options + explanation) |
| l4s5q2 | 4.5 | IN SCOPE | 4.5 'Reading global variables' | - | keep |
| l4s5q3 | 4.5 | IN SCOPE | 4.5 'Same name, different box' | - | keep |
| l4s5q4 | 4.5 | IN SCOPE | 4.5 'Local variables' + bullets | Correct option much longer than the distractors (1.6x) | rewritten (options) |
| l4s5q5 | 4.5 | IN SCOPE | 4.5 bullets: each call gets fresh local variables | - | keep |
| l4s5q6 | 4.5 | IN SCOPE | 4.5 'Pass in, return out' + Common mistake | AMBIGUOUS: distractor 'Rename n to total' also removes the error (def add(total): total = total + total runs fine); correct option 2.4x longer and the only one with code | rewritten (options + explanation) |
| l4s5q7 | 4.5 | IN SCOPE | 4.5 bullets: each call gets fresh local variables | - | keep |
| l5s1q1 | 5.1 | IN SCOPE | 5.1 'Many values, one variable' text: square brackets | Distractors {1, 2, 3} and (1, 2, 3) are set/tuple syntax never taught; explanation mentions 'other kinds of collections' | rewritten (distractors + explanation) |
| l5s1q2 | 5.1 | IN SCOPE | 5.1 'Lists can hold anything' len() | - | keep |
| l5s1q3 | 5.1 | IN SCOPE | 5.1 'Is it in the list?' | - | keep |
| l5s1q4 | 5.1 | IN SCOPE | 5.1 'Is it in the list?' Common mistake (missing comma) | - | keep |
| l5s2q1 | 5.2 | IN SCOPE | 5.2 'Positions start at 0' | - | keep |
| l5s2q2 | 5.2 | IN SCOPE | 5.2 'Counting from the end' | - | keep |
| l5s2q3 | 5.2 | IN SCOPE | 5.2 'Slicing' | - | keep |
| l5s2q4 | 5.2 | IN SCOPE | 5.2 'Index out of range' | Correct option 1.7x longer and the only one with a reason | rewritten (options + explanation) |
| l5s2q5 | 5.2 | IN SCOPE | 5.2 'Slicing' (leave out start) | - | keep |
| l5s2q6 | 5.2 | IN SCOPE | 5.2 'Changing an item' | - | keep |
| l5s3q1 | 5.3 | IN SCOPE | 5.3 'Adding with append()' | Distractor [1, 2, [3]] shows a nested list, never taught | rewritten (one distractor + explanation) |
| l5s3q2 | 5.3 | IN SCOPE | 5.3 'Sorting' | - | keep |
| l5s3q3 | 5.3 | IN SCOPE | 5.3 'Removing items' explain: pop() removes the last item and gives it back | Prompt says 'when you give it no index' (pop(index) never taught); correct option 1.6x longer | rewritten (prompt + distractors + explanation) |
| l5s3q4 | 5.3 | IN SCOPE | 5.3 'Methods change the list' + Common mistake | Correct option uses 'in place' (not defined in 5.3) and is 1.5x longer | rewritten (options + explanation) |
| l5s3q5 | 5.3 | OUT OF SCOPE | MISSING: rule that / always gives a float (20.0) is not taught anywhere; / itself is never introduced (only used once in 'max, min, sum and len') | Tests an untaught rule | replaced (insert(), taught on 'Adding at a position with insert()') |
| l5s4q1 | 5.4 | IN SCOPE | 5.4 'for item in list' | - | keep |
| l5s4q2 | 5.4 | IN SCOPE | 5.4 'for item in list' (prices total) | - | keep |
| l5s4q3 | 5.4 | IN SCOPE | 5.4 'Building a new list' Common mistake range(marks) | - | keep |
| l5s4q4 | 5.4 | IN SCOPE | 5.4 'Building a new list' | - | keep |
| l5s5q1 | 5.5 | REVIEW | Comprehension from 5.5; range(3) giving 0, 1, 2 is from 3.4 'Staying on one line' (the only REVIEW in 5.5) | - | keep |
| l5s5q2 | 5.5 | IN SCOPE | 5.5 'Adding a filter' | - | keep |
| l5s5q3 | 5.5 | IN SCOPE | 5.5 'A shortcut for building lists' | Correct option 1.6x longer than the distractors | rewritten (options + explanation) |
| l5s5q4 | 5.5 | IN SCOPE | 5.5 'Keep it simple' Common mistake (value first) | Correct option is the only one containing code (gives the answer away) | rewritten (options + explanation) |
| l5s5q5 | 5.5 | IN SCOPE | 5.5 'Reading a comprehension' (name + "!") | - | keep |
| l5s5q6 | 5.5 | IN SCOPE | 5.5 'Adding a filter'; % from 3.3 | Distractor uses the keyword and, never taught | rewritten (one distractor + explanation) |
| l5s5q7 | 5.5 | IN SCOPE | 5.5 key point: always makes a new list | - | keep |
| l5s5q8 | 5.5 | IN SCOPE | 5.5 'Adding a filter'; != from 2.1 | - | keep |
| l6s1q1 | 6.1 | IN SCOPE | 6.1 'Strings have methods too' | - | keep |
| l6s1q2 | 6.1 | IN SCOPE | 6.1 'Cleaning text with strip()' | - | keep |
| l6s1q3 | 6.1 | IN SCOPE | 6.1 'Splitting and joining' | - | keep |
| l6s1q4 | 6.1 | IN SCOPE | 6.1 'Strings are like lists of letters' Common mistake | - | keep |
| l6s1q5 | 6.1 | IN SCOPE | 6.1 'Splitting and joining' | - | keep |
| l6s1q6 | 6.1 | IN SCOPE | 6.1 'Finding and replacing' count() | - | keep |
| l6s2q1 | 6.2 | IN SCOPE | 6.2 'Decimal places' | - | keep |
| l6s2q2 | 6.2 | IN SCOPE | 6.2 'Lining up columns' Common mistake (forgetting the f) | - | keep |
| l6s2q3 | 6.2 | IN SCOPE | 6.2 'Lining up columns' | - | keep |
| l6s2q4 | 6.2 | IN SCOPE | 6.2 'f-strings can do maths' | - | keep |
| l6s2q5 | 6.2 | IN SCOPE | 6.2 'Decimal places' | WRONG EXPLANATION: ':2f doesn't round anything' is false; Python 3.11 prints 12.345600 (6 decimals) | rewritten (explanation) |
| l6s3q1 | 6.3 | IN SCOPE | 6.3 'Labels instead of positions' | - | keep |
| l6s3q2 | 6.3 | IN SCOPE | 6.3 'Adding and changing' + key point | - | keep |
| l6s3q3 | 6.3 | IN SCOPE | 6.3 'Safe lookups with get()' | - | keep |
| l6s3q4 | 6.3 | IN SCOPE | 6.3 'Labels instead of positions' | - | keep |
| l6s3q5 | 6.3 | IN SCOPE | 6.3 'Missing keys' tip: keys are case-sensitive | - | keep |
| l6s3q6 | 6.3 | IN SCOPE | 6.3 'Checking and removing' len() counts the pairs | - | keep |
| l6s3q7 | 6.3 | IN SCOPE | 6.3 'Counting with a dictionary' | AMBIGUOUS: distractor pop also works (counts.pop(word, 0) + 1 gives correct counts); find/index are methods never mentioned | rewritten (distractors + explanation) |
| l6s3q8 | 6.3 | IN SCOPE | 6.3 key point: keys are unique | - | keep |
| l6s4q1 | 6.4 | IN SCOPE | 6.4 'Looping over keys' | Distractor ('a', 1) uses tuple display, never taught | rewritten (one distractor) |
| l6s4q2 | 6.4 | IN SCOPE | 6.4 'keys(), values() and items()' | Distractor ('x', 3) uses tuple display, never taught | rewritten (one distractor + explanation) |
| l6s4q3 | 6.4 | IN SCOPE | 6.4 key point: sum(d.values()) | - | keep |
| l6s4q4 | 6.4 | IN SCOPE | 6.4 'keys(), values() and items()' | Correct option 2.2x longer than the distractors | rewritten (distractors) |
| l6s4q5 | 6.4 | IN SCOPE | 6.4 'Forgetting items()' + Common mistake | - | keep |
| l6s4q6 | 6.4 | IN SCOPE | 6.4 bullets: for v in d.values() | - | keep |

### Answer-position balance (check 7)

| Sub-level | Before (positions) | Counts 0/1/2/3 before | After | Counts after | Flag before |
|---|---|---|---|---|---|
| 1.1 | [1, 2, 1, 2] | 0/2/2/0 | [1, 2, 1, 2] | 0/2/2/0 | ok |
| 1.2 | [0, 1, 2, 2] | 1/1/2/0 | [0, 1, 2, 2] | 1/1/2/0 | ok |
| 1.3 | [2, 1, 1, 3] | 0/2/1/1 | [2, 1, 1, 3] | 0/2/1/1 | ok |
| 1.4 | [1, 0, 2, 2] | 1/1/2/0 | [1, 0, 2, 2] | 1/1/2/0 | ok |
| 2.1 | [0, 1, 1] | 1/2/0/0 | [0, 1, 2] | 1/1/1/0 | one position > half |
| 2.2 | [1, 1, 1] | 0/3/0/0 | [0, 1, 2] | 1/1/1/0 | one position > half, 3 in a row |
| 2.3 | [0, 1, 1] | 1/2/0/0 | [0, 1, 2] | 1/1/1/0 | one position > half |
| 3.1 | [3, 0, 1, 0, 2] | 2/1/1/1 | [3, 0, 1, 0, 2] | 2/1/1/1 | ok |
| 3.2 | [1, 3, 2, 0, 0, 1] | 2/2/1/1 | [1, 3, 2, 0, 0, 1] | 2/2/1/1 | ok |
| 3.3 | [0, 3, 2, 1] | 1/1/1/1 | [0, 3, 2, 1] | 1/1/1/1 | ok |
| 3.4 | [1, 1, 0, 3, 2, 2, 0, 3] | 2/2/2/2 | [1, 1, 0, 3, 2, 2, 0, 3] | 2/2/2/2 | ok |
| 4.1 | [0, 0, 1, 3, 2] | 2/1/1/1 | [0, 0, 1, 3, 2] | 2/1/1/1 | ok |
| 4.2 | [0, 1, 2] | 1/1/1/0 | [0, 1, 2] | 1/1/1/0 | ok |
| 4.3 | [1, 3, 1, 2, 0, 0] | 2/2/1/1 | [1, 3, 1, 2, 0, 0] | 2/2/1/1 | ok |
| 4.4 | [3, 1, 2, 0] | 1/1/1/1 | [3, 1, 2, 0] | 1/1/1/1 | ok |
| 4.5 | [1, 0, 2, 2, 0, 1, 3] | 2/2/2/1 | [1, 0, 2, 2, 0, 1, 3] | 2/2/2/1 | ok |
| 5.1 | [1, 0, 2, 3] | 1/1/1/1 | [1, 0, 2, 3] | 1/1/1/1 | ok |
| 5.2 | [0, 0, 1, 1, 3, 2] | 2/2/1/1 | [0, 0, 1, 1, 3, 2] | 2/2/1/1 | ok |
| 5.3 | [0, 2, 3, 0, 1] | 2/1/1/1 | [0, 2, 3, 0, 1] | 2/1/1/1 | ok |
| 5.4 | [0, 1, 2, 3] | 1/1/1/1 | [0, 1, 2, 3] | 1/1/1/1 | ok |
| 5.5 | [1, 0, 0, 3, 2, 1, 3, 2] | 2/2/2/2 | [1, 0, 0, 3, 2, 1, 3, 2] | 2/2/2/2 | ok |
| 6.1 | [0, 1, 0, 3, 2, 1] | 2/2/1/1 | [0, 1, 0, 3, 2, 1] | 2/2/1/1 | ok |
| 6.2 | [3, 0, 1, 2, 0] | 2/1/1/1 | [3, 0, 1, 2, 0] | 2/1/1/1 | ok |
| 6.3 | [3, 2, 1, 0, 1, 2, 3, 0] | 2/2/2/2 | [3, 2, 1, 0, 1, 2, 3, 0] | 2/2/2/2 | ok |
| 6.4 | [0, 3, 0, 1, 2, 1] | 2/2/1/1 | [0, 3, 0, 1, 2, 1] | 2/2/1/1 | ok |

Levels 3-6 place the correct answer automatically (`balanced()` uses the sub-level id and the question count as the seed), so their positions are unchanged after the edits. Level 1-2 positions are set by hand; 2.1, 2.2 and 2.3 were rebalanced by reordering options only.
### Lesson coverage gaps (check 6, for information only)

Concepts taught on the lesson pages that no question tests. No questions were added for these.

| Sub-level | Taught but not tested |
|---|---|
| 1.1 | Each print() call starts a new line; comments at the end of a line |
| 1.2 | Names are case-sensitive (Age vs age); "= means store, not is equal to" (only partly, via l1s2q1) |
| 1.3 | type() and its output; str() and float() conversions; "5" vs 5 |
| 1.4 | print with several values separated by commas; type(input(...)) is str |
| 2.1 | !=, <=, > (only as distractors or not at all) |
| 2.2 | An if without else (nothing runs when False); the "Watch out" missing-colon/indent error |
| 2.3 | Order matters / put the most specific condition first |
| 3.1 | Loop variable used in calculations (times table); range(1, 6) style counting values (l3s1q2 covers range(2, 6)) |
| 3.2 | while with input() (ask until right); savings doubling; choosing for vs while |
| 3.3 | while True with break; the break-indentation mistake |
| 3.4 | Empty print() to finish a line; "ab" * "3" is an error; multiplication grid |
| 4.1 | NameError when calling a function above its def |
| 4.2 | TypeError for a missing argument; swapping argument order (describe("Tom", 3) vs describe(3, "Tom")) |
| 4.3 | Using returned values directly in maths (square(3) + square(4)); lines after return never run |
| 4.4 | Skipping one default while changing another (order("coffee", sugar=0)) |
| 4.5 | Same name inside and outside covered; nothing major missing |
| 5.1 | Empty list [] and len 0; one list mixing types |
| 5.2 | -2 and other negative indexes; slice with no stop (nums[3:]); len(list) - 1 as the last index |
| 5.3 | remove(); max()/min(); sort(reverse=True); count(x); the average sum()/len() (no longer tested after replacing l5s3q5) |
| 5.4 | Nothing major missing |
| 5.5 | Comprehension over a list of strings (name + "!") is partly covered by l5s5q5 |
| 6.1 | lower(); replace(); startswith(); indexing a string and looping over its letters |
| 6.2 | :<8 left-align; :.1f; single quotes inside a double-quoted f-string |
| 6.3 | in on a dictionary; pop(key); KeyError on a missing key (only via case-sensitivity) |
| 6.4 | keys() and list(); the "best value so far" pattern; max(d.values()), len(d) |

## 3. Lesson problems (not changed, please review)

1. **3.1 "Your first for loop" / "Counting with range()"**: the lesson never says that `range(n)` starts at 0. It only says "range(5) means do this 5 times". The first time learners see `range(n)` values is 3.4 (`range(2)` prints 0, 1). Three questions (l3s1q1, l3s3q1, l3s3q2) depended on it, and I rewrote them. A short line in 3.1 such as "range(5) gives 0, 1, 2, 3, 4" would close this gap.
2. **5.3 "max, min, sum and len"**: the division operator `/` is used (`sum(marks) / len(marks)`) but never introduced. The lesson also never says that `/` always gives a float (the old l5s3q5 tested exactly that).
3. **5.3 "Methods change the list"**: "Methods like append() and sort() ... give back None" sits next to pop(), which does give back a value. Consider saying "append(), insert(), remove() and sort() give back None; pop() gives back the removed item."
4. **5.3 bullets**: `count(x)` is listed but never shown in code, while `remove()` is shown but has no Common-mistake note (it removes only the first match, and raises an error if the value is missing).
5. **6.1 "Strings have methods too"**: the term "changed in place" is used without being defined (5.3 says "change the list itself").
6. **4.1**: the word "keyword" is never defined, but 4.4 later uses "keyword arguments" with a different meaning. Fine for now, but worth one sentence.
7. **1.2 "Naming rules"**: there's no mention of reserved words (for example `class` or `if` can't be variable names). Minor.
8. **1.1 / 1.4**: single-quoted strings ('text') never appear until Level 5 list output, but they're used in 6.2 f-string examples. 6.2 explains them, so this is OK, but worth knowing.

No factual errors were found in the lesson text or in the shown outputs (the build script runs every lesson example and checks its output).
## 4. Corrected content

The edited `PyPath/content/build_course.py` and all six regenerated level files are attached, so you do not have to copy anything by hand. The entries below are exactly what is now in the file.

Levels 3-6 use `m(prompt, right, wrongs, explanation, code_=..., check=...)`: the id (`<sub-level>q<n>`) comes from the question's position in the list, and `balanced()` sets the correctIndex. Levels 1-2 use `q(id, prompt, options, correctIndex, explanation, code_=...)`.

| Level | Changed / total | Shown below |
|---|---|---|
| 1 | 11 / 16 (69%) | entire quiz lists (about 30% or more changed) |
| 2 | 5 / 9 (56%) | entire quiz lists (about 30% or more changed) |
| 3 | 5 / 23 (22%) | changed questions only |
| 4 | 7 / 25 (28%) | entire quiz lists (about 30% or more changed) |
| 5 | 9 / 27 (33%) | entire quiz lists (about 30% or more changed) |
| 6 | 5 / 25 (20%) | changed questions only |

### Level 1

#### 1.1: `sub("l1s1", ...)` quiz list, lines 129-138

```python
        # l1s1q1  (changed)
        q("l1s1q1", "What does print() do in Python?",
          ["Runs the program again", "Shows something on the screen", "Turns text into a comment", "Ends the program"], 1,
          "print() shows whatever you put inside the parentheses on the screen. It does not restart or end the program, and only # makes a comment."),
        # l1s1q2  (changed)
        q("l1s1q2", "What will this code display?", ["2 + 3", "\"5\"", "5", "Error"], 2,
          "Without quotes, 2 + 3 is maths, so Python works it out and prints 5. print shows the value without quotes, so it is not \"5\", and you would only see 2 + 3 if it were inside quotes.", code_="print(2 + 3)"),
        # l1s1q3  (changed)
        q("l1s1q3", "Which symbol starts a comment in Python?", ["//", "#", "--", "/*"], 1,
          "In Python, everything after # on a line is a comment that Python ignores. //, -- and /* are used in other languages, not in Python."),
        # l1s1q4  (changed)
        q("l1s1q4", "In what order does Python run your lines of code?",
          ["Random order", "Bottom to top", "Top to bottom", "Shortest line first"], 2,
          "Python reads your code line by line, starting at the top, so the first line runs first. It never picks lines at random or starts from the bottom."),
```

#### 1.2: `sub("l1s2", ...)` quiz list, lines 177-185

```python
        # l1s2q1  (changed)
        q("l1s2q1", "Which line correctly creates a variable?",
          ["city = \"Pune\"", "\"Pune\" = city", "city \"Pune\"", "var city = \"Pune\""], 0,
          "The variable name goes on the left, then a single =, then the value. Putting the value on the left is backwards, leaving out = stores nothing, and Python does not use the word var."),
        # l1s2q2  (unchanged)
        q("l1s2q2", "What does this code print?", ["10", "15", "25", "score"], 1,
          "The second assignment replaces 10 with 15.", code_="score = 10\nscore = 15\nprint(score)"),
        # l1s2q3  (unchanged)
        q("l1s2q3", "Which is a valid variable name?", ["2fast", "my name", "user_age", "class-1"], 2,
          "Names can use letters, digits and underscores but can't start with a digit or contain spaces/hyphens."),
        # l1s2q4  (changed)
        q("l1s2q4", "What is printed?", ["a + b", "34", "7", "Error"], 2,
          "a is 3 and b is 4, so a + b is 7. print shows the values, not the words a + b, and numbers are added, so the answer is not 34.", code_="a = 3\nb = 4\nprint(a + b)"),
```

#### 1.3: `sub("l1s3", ...)` quiz list, lines 223-230

```python
        # l1s3q1  (changed)
        q("l1s3q1", "What is the type of 3.14?", ["int", "str", "float", "bool"], 2,
          "3.14 has a decimal point, so it is a float. int is only for whole numbers like 42, and a str would need quotes."),
        # l1s3q2  (unchanged)
        q("l1s3q2", "What does this code print?", ["5", "23", "2 + 3", "Error"], 1,
          "Both values are strings, so + joins them into \"23\".", code_='print("2" + "3")'),
        # l1s3q3  (changed)
        q("l1s3q3", "Which value is a bool?", ["\"True\"", "True", "1.0", "\"yes\""], 1,
          "True without quotes is a bool. \"True\" and \"yes\" have quotes, so they are text (str), and 1.0 is a float."),
        # l1s3q4  (changed)
        q("l1s3q4", "Which function converts \"42\" into a whole number?", ["str()", "float()", "type()", "int()"], 3,
          "int() turns text like \"42\" into the whole number 42. float() gives a decimal number, str() makes text, and type() only tells you the type."),
```

#### 1.4: `sub("l1s4", ...)` quiz list, lines 272-281

```python
        # l1s4q1  (unchanged)
        q("l1s4q1", "What does input() return?", ["A number", "A string", "A bool", "Nothing"], 1,
          "input() always returns what the user typed as a string."),
        # l1s4q2  (changed)
        q("l1s4q2", "How do you turn the user's answer into a whole number?",
          ["int(input())", "input(int())", "number(input())", "input().int"], 0,
          "input() gives the answer as text, and wrapping it in int() turns that text into a whole number. input(int()) puts int() inside the question instead, and Python has no number() function or .int."),
        # l1s4q3  (unchanged)
        q("l1s4q3", "What does this print?", ["{x} apples", "x apples", "5 apples", "f5 apples"], 2,
          "In an f-string, {x} is replaced with the value of x.", code_='x = 5\nprint(f"{x} apples")'),
        # l1s4q4  (changed)
        q("l1s4q4", "What is shown to the user by input(\"Age: \")?",
          ["Nothing", "The word input", "Age: ", "An error"], 2,
          "The text inside input() is the question shown to the user before they type, so they see Age: . It is not an error, and Python shows your text, not the word input."),
```

#### Level 1: matching entries in `levels/l1.json`

```json
[
  {
    "id": "l1s1q1",
    "prompt": "What does print() do in Python?",
    "options": [
      "Runs the program again",
      "Shows something on the screen",
      "Turns text into a comment",
      "Ends the program"
    ],
    "correctIndex": 1,
    "explanation": "print() shows whatever you put inside the parentheses on the screen. It does not restart or end the program, and only # makes a comment."
  },
  {
    "id": "l1s1q2",
    "prompt": "What will this code display?",
    "options": [
      "2 + 3",
      "\"5\"",
      "5",
      "Error"
    ],
    "correctIndex": 2,
    "explanation": "Without quotes, 2 + 3 is maths, so Python works it out and prints 5. print shows the value without quotes, so it is not \"5\", and you would only see 2 + 3 if it were inside quotes.",
    "code": "print(2 + 3)"
  },
  {
    "id": "l1s1q3",
    "prompt": "Which symbol starts a comment in Python?",
    "options": [
      "//",
      "#",
      "--",
      "/*"
    ],
    "correctIndex": 1,
    "explanation": "In Python, everything after # on a line is a comment that Python ignores. //, -- and /* are used in other languages, not in Python."
  },
  {
    "id": "l1s1q4",
    "prompt": "In what order does Python run your lines of code?",
    "options": [
      "Random order",
      "Bottom to top",
      "Top to bottom",
      "Shortest line first"
    ],
    "correctIndex": 2,
    "explanation": "Python reads your code line by line, starting at the top, so the first line runs first. It never picks lines at random or starts from the bottom."
  },
  {
    "id": "l1s2q1",
    "prompt": "Which line correctly creates a variable?",
    "options": [
      "city = \"Pune\"",
      "\"Pune\" = city",
      "city \"Pune\"",
      "var city = \"Pune\""
    ],
    "correctIndex": 0,
    "explanation": "The variable name goes on the left, then a single =, then the value. Putting the value on the left is backwards, leaving out = stores nothing, and Python does not use the word var."
  },
  {
    "id": "l1s2q4",
    "prompt": "What is printed?",
    "options": [
      "a + b",
      "34",
      "7",
      "Error"
    ],
    "correctIndex": 2,
    "explanation": "a is 3 and b is 4, so a + b is 7. print shows the values, not the words a + b, and numbers are added, so the answer is not 34.",
    "code": "a = 3\nb = 4\nprint(a + b)"
  },
  {
    "id": "l1s3q1",
    "prompt": "What is the type of 3.14?",
    "options": [
      "int",
      "str",
      "float",
      "bool"
    ],
    "correctIndex": 2,
    "explanation": "3.14 has a decimal point, so it is a float. int is only for whole numbers like 42, and a str would need quotes."
  },
  {
    "id": "l1s3q3",
    "prompt": "Which value is a bool?",
    "options": [
      "\"True\"",
      "True",
      "1.0",
      "\"yes\""
    ],
    "correctIndex": 1,
    "explanation": "True without quotes is a bool. \"True\" and \"yes\" have quotes, so they are text (str), and 1.0 is a float."
  },
  {
    "id": "l1s3q4",
    "prompt": "Which function converts \"42\" into a whole number?",
    "options": [
      "str()",
      "float()",
      "type()",
      "int()"
    ],
    "correctIndex": 3,
    "explanation": "int() turns text like \"42\" into the whole number 42. float() gives a decimal number, str() makes text, and type() only tells you the type."
  },
  {
    "id": "l1s4q2",
    "prompt": "How do you turn the user's answer into a whole number?",
    "options": [
      "int(input())",
      "input(int())",
      "number(input())",
      "input().int"
    ],
    "correctIndex": 0,
    "explanation": "input() gives the answer as text, and wrapping it in int() turns that text into a whole number. input(int()) puts int() inside the question instead, and Python has no number() function or .int."
  },
  {
    "id": "l1s4q4",
    "prompt": "What is shown to the user by input(\"Age: \")?",
    "options": [
      "Nothing",
      "The word input",
      "Age: ",
      "An error"
    ],
    "correctIndex": 2,
    "explanation": "The text inside input() is the question shown to the user before they type, so they see Age: . It is not an error, and Python shows your text, not the word input."
  }
]
```

### Level 2

#### 2.1: `sub("l2s1", ...)` quiz list, lines 308-313

```python
        # l2s1q1  (unchanged)
        q("l2s1q1", "What does 7 >= 7 give?", ["True", "False", "7", "Error"], 0,
          ">= is True when the left side is greater than OR equal to the right."),
        # l2s1q2  (unchanged)
        q("l2s1q2", "Which operator checks if two values are equal?", ["=", "==", "!=", "=>"], 1,
          "== compares values; = assigns a value to a variable."),
        # l2s1q3  (changed)
        q("l2s1q3", "What is printed?", ["True", "10", "False", "Error"], 2,
          "10 is not less than 3, so the comparison is False.", code_="print(10 < 3)"),
```

#### 2.2: `sub("l2s2", ...)` quiz list, lines 337-344

```python
        # l2s2q1  (changed)
        q("l2s2q1", "What must end an if line?", ["A colon :", "A semicolon ;", "A period .", "Nothing"], 0,
          "Every if line, and every else line, ends with a colon :. Leaving it out is an error, and Python does not use ; or . here."),
        # l2s2q2  (unchanged)
        q("l2s2q2", "What is printed?", ["Big", "Small", "Big and Small", "Nothing"], 1,
          "3 > 10 is False, so the else branch runs.",
          code_='n = 3\nif n > 10:\n    print("Big")\nelse:\n    print("Small")'),
        # l2s2q3  (changed)
        q("l2s2q3", "How does Python know which lines belong to an if?",
          ["Curly braces { }", "The word end", "Indentation", "Line numbers"], 2,
          "Python groups the lines of an if by indentation, usually 4 spaces. It does not use curly braces, an end word or line numbers for this."),
```

#### 2.3: `sub("l2s3", ...)` quiz list, lines 364-371

```python
        # l2s3q1  (changed)
        q("l2s3q1", "What does elif mean?", ["else if", "end if", "exit if", "either if"], 0,
          "elif is short for else if: when the condition above is False, Python tries this one. It does not end or exit the if."),
        # l2s3q2  (unchanged)
        q("l2s3q2", "What is printed?", ["High", "Medium", "Low", "High and Medium"], 1,
          "50 > 80 is False; 50 > 30 is True, so Medium prints and the rest are skipped.",
          code_='x = 50\nif x > 80:\n    print("High")\nelif x > 30:\n    print("Medium")\nelse:\n    print("Low")'),
        # l2s3q3  (changed)
        q("l2s3q3", "In one if / elif / else chain, how many of the branches run?",
          ["Every branch that is True", "Two", "Exactly one", "None of them"], 2,
          "Python checks the conditions from top to bottom and runs only the first branch that is True, or the else if none are. Later branches are skipped even if their condition is also True."),
```

#### Level 2: matching entries in `levels/l2.json`

```json
[
  {
    "id": "l2s1q3",
    "prompt": "What is printed?",
    "options": [
      "True",
      "10",
      "False",
      "Error"
    ],
    "correctIndex": 2,
    "explanation": "10 is not less than 3, so the comparison is False.",
    "code": "print(10 < 3)"
  },
  {
    "id": "l2s2q1",
    "prompt": "What must end an if line?",
    "options": [
      "A colon :",
      "A semicolon ;",
      "A period .",
      "Nothing"
    ],
    "correctIndex": 0,
    "explanation": "Every if line, and every else line, ends with a colon :. Leaving it out is an error, and Python does not use ; or . here."
  },
  {
    "id": "l2s2q3",
    "prompt": "How does Python know which lines belong to an if?",
    "options": [
      "Curly braces { }",
      "The word end",
      "Indentation",
      "Line numbers"
    ],
    "correctIndex": 2,
    "explanation": "Python groups the lines of an if by indentation, usually 4 spaces. It does not use curly braces, an end word or line numbers for this."
  },
  {
    "id": "l2s3q1",
    "prompt": "What does elif mean?",
    "options": [
      "else if",
      "end if",
      "exit if",
      "either if"
    ],
    "correctIndex": 0,
    "explanation": "elif is short for else if: when the condition above is False, Python tries this one. It does not end or exit the if."
  },
  {
    "id": "l2s3q3",
    "prompt": "In one if / elif / else chain, how many of the branches run?",
    "options": [
      "Every branch that is True",
      "Two",
      "Exactly one",
      "None of them"
    ],
    "correctIndex": 2,
    "explanation": "Python checks the conditions from top to bottom and runs only the first branch that is True, or the else if none are. Later branches are skipped even if their condition is also True."
  }
]
```

### Level 3

#### 3.1: `lesson("l3s1", ...)`

l3s1q1, question 1 in the list, line 454:

```python
        m("What does this code print?", "0\n3\n6", ["0\n3\n6\n9", "3\n6\n9", "0\n1\n2"],
          "range(0, 9, 3) starts at 0 and jumps by 3: 0, 3, 6. 9 is the stop number and range always stops before it, so 9 is not printed. The third number is the step, so it does not count 0, 1, 2.",
          code_="for n in range(0, 9, 3):\n    print(n)", check="out"),
```

l3s1q4, question 4 in the list, line 463:

```python
        m("Fill in the blank so the loop prints the numbers 1 to 10.", "1, 11", ["1, 10", "0, 10", "10"],
          "The stop number is never included, so to reach 10 you stop at 11. range(1, 10) would stop at 9.",
          code_="for n in range(____):\n    print(n)"),
```

#### 3.3: `lesson("l3s3", ...)`

l3s3q1, question 1 in the list, line 599:

```python
        m("What does this code print?", "1\n2", ["1\n2\n3", "3", "1\n2\n4\n5"],
          "When n is 3, break ends the loop before print runs, so only 1 and 2 are shown. break does not skip just one number — it stops the loop.",
          code_="for n in range(1, 6):\n    if n == 3:\n        break\n    print(n)", check="out"),
```

l3s3q2, question 2 in the list, line 602:

```python
        m("What does this code print?", "1\n3\n4", ["1\n2\n3\n4", "1", "3\n4"],
          "continue skips only the repeat where n is 2. The loop keeps going, so 3 and 4 are still printed. Stopping after 1 is what break would do.",
          code_="for n in range(1, 5):\n    if n == 2:\n        continue\n    print(n)", check="out"),
```

#### 3.4: `lesson("l3s4", ...)`

l3s4q7, question 7 in the list, line 720:

```python
        m("To print 1 2 3 on one line, what goes in the blank? print(n, ____)", 'end=" "',
          ['space=" "', '" "', "line=False"],
          'end=" " replaces the new line with a space. Writing just " " prints a space as a second value but still moves to a new line every time, and print has no space or line setting.',
          code_="for n in range(1, 4):\n    print(n, ____)"),
```

#### Level 3: matching entries in `levels/l3.json`

```json
[
  {
    "id": "l3s1q1",
    "prompt": "What does this code print?",
    "options": [
      "0\n3\n6\n9",
      "3\n6\n9",
      "0\n1\n2",
      "0\n3\n6"
    ],
    "correctIndex": 3,
    "explanation": "range(0, 9, 3) starts at 0 and jumps by 3: 0, 3, 6. 9 is the stop number and range always stops before it, so 9 is not printed. The third number is the step, so it does not count 0, 1, 2.",
    "code": "for n in range(0, 9, 3):\n    print(n)"
  },
  {
    "id": "l3s1q4",
    "prompt": "Fill in the blank so the loop prints the numbers 1 to 10.",
    "options": [
      "1, 11",
      "1, 10",
      "0, 10",
      "10"
    ],
    "correctIndex": 0,
    "explanation": "The stop number is never included, so to reach 10 you stop at 11. range(1, 10) would stop at 9.",
    "code": "for n in range(____):\n    print(n)"
  },
  {
    "id": "l3s3q1",
    "prompt": "What does this code print?",
    "options": [
      "1\n2",
      "1\n2\n3",
      "3",
      "1\n2\n4\n5"
    ],
    "correctIndex": 0,
    "explanation": "When n is 3, break ends the loop before print runs, so only 1 and 2 are shown. break does not skip just one number — it stops the loop.",
    "code": "for n in range(1, 6):\n    if n == 3:\n        break\n    print(n)"
  },
  {
    "id": "l3s3q2",
    "prompt": "What does this code print?",
    "options": [
      "1\n2\n3\n4",
      "1",
      "3\n4",
      "1\n3\n4"
    ],
    "correctIndex": 3,
    "explanation": "continue skips only the repeat where n is 2. The loop keeps going, so 3 and 4 are still printed. Stopping after 1 is what break would do.",
    "code": "for n in range(1, 5):\n    if n == 2:\n        continue\n    print(n)"
  },
  {
    "id": "l3s4q7",
    "prompt": "To print 1 2 3 on one line, what goes in the blank? print(n, ____)",
    "options": [
      "end=\" \"",
      "space=\" \"",
      "\" \"",
      "line=False"
    ],
    "correctIndex": 0,
    "explanation": "end=\" \" replaces the new line with a space. Writing just \" \" prints a space as a second value but still moves to a new line every time, and print has no space or line setting.",
    "code": "for n in range(1, 4):\n    print(n, ____)"
  }
]
```

### Level 4

#### 4.1: `lesson("l4s1", ...)` quiz list, lines 775-789

```python
        # l4s1q1  (changed)
        m("Which word starts a function definition?", "def", ["function", "func", "define"],
          "Python uses def. Other languages use words like function, which is why it's a common guess."),
        # l4s1q2  (unchanged)
        m("What does this code print?", "B\nA", ["A\nB", "B", "A"],
          "The def is only remembered, not run. print(\"B\") runs first, then show() prints A.",
          code_='def show():\n    print("A")\n\nprint("B")\nshow()', check="out"),
        # l4s1q3  (unchanged)
        m("Find the bug.", "The colon : is missing at the end of the def line",
          ["Function names must be written in capitals", "print must not be indented", "def lines need a semicolon"],
          "Like if and for, a def line ends with a colon. Lowercase names and an indented body are correct.",
          code_='def hello()\n    print("hi")'),
        # l4s1q4  (unchanged)
        m("What does this code print?", "beep\nbeep\nbeep", ["beep", "beep()\nbeep()\nbeep()", "Nothing, the function is never called"],
          "beep() is called three times and each call prints beep once.",
          code_='def beep():\n    print("beep")\n\nbeep()\nbeep()\nbeep()', check="out"),
        # l4s1q5  (unchanged)
        m("What happens when Python reads a def block?", "It remembers the function but does not run its body yet",
          ["It runs the body immediately", "It prints the function's name", "It deletes the function after one call"],
          "The body only runs when the function is called. That's why you can define a function and use it many times later."),
```

#### 4.2: `lesson("l4s2", ...)` quiz list, lines 842-850

```python
        # l4s2q1  (unchanged)
        m("What does this code print?", "Hi!", ["word!", "Hi", "Error"],
          "word holds \"Hi\", and + joins it with \"!\". The name word is not printed — its value is.",
          code_='def shout(word):\n    print(word + "!")\n\nshout("Hi")', check="out"),
        # l4s2q2  (changed)
        m("In def area(width, height):, what are width and height?", "Parameters",
          ["Arguments", "Function names", "Function calls"],
          "The names in the def line are parameters. Arguments are the values you pass when calling, like area(3, 4). The function's name is area, and area(3, 4) is a call."),
        # l4s2q3  (unchanged)
        m("What does this code print?", "-7", ["7", "3 - 10", "Error"],
          "a is 3 and b is 10 because arguments are matched in order, so a - b is -7.",
          code_="def minus(a, b):\n    print(a - b)\n\nminus(3, 10)", check="out"),
```

#### 4.3: `lesson("l4s3", ...)` quiz list, lines 916-935

```python
        # l4s3q1  (unchanged)
        m("What does this code print?", "12", ["7", "444", "None"],
          "x * 3 with x = 4 is 12, and return sends it back to print. 7 would be 4 + 3, which is not what * does.",
          code_="def triple(x):\n    return x * 3\n\nprint(triple(4))", check="out"),
        # l4s3q2  (unchanged)
        m("What does this code print?", "3\nNone", ["3\n3", "None", "3"],
          "f prints 3 but has no return, so y is None. Both lines appear: first 3 from inside f, then None.",
          code_="def f(x):\n    print(x)\n\ny = f(3)\nprint(y)", check="out"),
        # l4s3q3  (changed)
        m("What does return do?", "Sends a value back to the code that called it and ends the function",
          ["Prints the value on the screen for the user", "Runs the function again from the very top",
           "Saves the value so every function can use it"],
          "return gives a value back to the code that called the function, and the function stops there. Showing it on screen is print's job, and return does not repeat the function."),
        # l4s3q4  (unchanged)
        m("This prints None instead of 10. What's the problem?", "The function never returns result",
          ["w and h must be named width and height", "print can't call a function", "result must be printed inside the function"],
          "result is calculated but not returned, so the call gives None. Adding return result fixes it.",
          code_="def area(w, h):\n    result = w * h\n\nprint(area(2, 5))"),
        # l4s3q5  (unchanged)
        m("What does this code print?", "negative", ["positive", "negative\npositive", "None"],
          "-2 < 0 is True, so the first return runs and the function ends. The second return is never reached.",
          code_='def sign(n):\n    if n < 0:\n        return "negative"\n    return "positive"\n\nprint(sign(-2))', check="out"),
        # l4s3q6  (unchanged)
        m("Fill in the blank so print(add(1, 2)) shows 3.", "return", ["print", "give", "result ="],
          "return a + b sends 3 back to print. Using print inside would show 3 but then print(add(1, 2)) would also show None.",
          code_="def add(a, b):\n    ____ a + b"),
```

#### 4.4: `lesson("l4s4", ...)` quiz list, lines 971-983

```python
        # l4s4q1  (unchanged)
        m("What does this code print?", "haha", ["ha", "hahaha", "Error: times is missing"],
          "times wasn't passed, so its default 2 is used and \"ha\" * 2 is \"haha\". No error, because the parameter has a default.",
          code_='def repeat(word, times=2):\n    print(word * times)\n\nrepeat("ha")', check="out"),
        # l4s4q2  (unchanged)
        m("What does this code print?", "Mia-9", ["9-Mia", "age-name", "Error"],
          "Keyword arguments are matched by name, not position, so name is \"Mia\" and age is 9.",
          code_='def info(name, age):\n    print(f"{name}-{age}")\n\ninfo(age=9, name="Mia")', check="out"),
        # l4s4q3  (unchanged)
        m("Which function definition causes a SyntaxError?", "def f(a=1, b):",
          ["def f(a, b=1):", "def f(a=1, b=2):", "def f(a, b):"],
          "A parameter without a default can't come after one with a default. The other three are all valid."),
        # l4s4q4  (changed)
        m("When is a default value used?", "When the caller doesn't pass a value for that parameter",
          ["Always, even when the caller passes a different value", "Only when the function has no return line",
           "Only when the call uses keyword arguments"],
          "A passed value always replaces the default. The default only fills in when nothing is given, with or without keyword arguments."),
```

#### 4.5: `lesson("l4s5", ...)` quiz list, lines 1048-1073

```python
        # l4s5q1  (changed)
        m("What happens when this runs?", "A NameError", ["It prints 5", "It prints None", "A TypeError"],
          "y is local to f and disappears when f ends, so print(y) can't find it and Python raises a NameError. Calling f() first doesn't make y available outside, so it does not print 5.",
          code_="def f():\n    y = 5\n\nf()\nprint(y)", check="err:NameError"),
        # l4s5q2  (unchanged)
        m("What does this code print?", "1", ["NameError", "None", "0"],
          "Functions can read global variables, so show() prints the global n.",
          code_="n = 1\n\ndef show():\n    print(n)\n\nshow()", check="out"),
        # l4s5q3  (unchanged)
        m("What does this code print?", "3", ["7", "None", "NameError"],
          "a = 7 inside set_a creates a new local a. The global a is untouched and is still 3.",
          code_="a = 3\n\ndef set_a():\n    a = 7\n\nset_a()\nprint(a)", check="out"),
        # l4s5q4  (changed)
        m("What is a local variable?", "A variable made inside a function that exists only during the call",
          ["A variable that every function in the file can change", "A variable created at the top of the file, outside functions",
           "A variable whose value can never be changed"],
          "Local means \"belongs to this function call\". A variable at the top of the file, outside all functions, is global."),
        # l4s5q5  (unchanged)
        m("Which statement is true?", "Each call of a function gets fresh local variables",
          ["Local variables keep their values between calls", "A function can't read variables from outside",
           "Parameters are global variables"],
          "Locals are created again on every call and thrown away at the end. Functions can read globals, and parameters are local."),
        # l4s5q6  (changed)
        m("Calling add(5) raises an error. What's the cleanest fix?",
          "Take total as a parameter and return total + n",
          ["Call add(5) twice so that total exists first", "Delete the line total = 0 at the top of the file",
           "Add print(total) as the first line inside add"],
          "Assigning total inside the function makes it local, so total + n has nothing to read yet. Passing total in and returning the new value (total = add(total, 5)) avoids the problem. Calling twice, deleting the global or printing it first still leaves total local, so the error stays.",
          code_="total = 0\n\ndef add(n):\n    total = total + n\n\nadd(5)"),
        # l4s5q7  (unchanged)
        m("What does this code print?", "1", ["2", "0", "None"],
          "c is a fresh local variable on every call: it starts at 0 and becomes 1. The first call's c doesn't carry over, so it's not 2.",
          code_="def count():\n    c = 0\n    c += 1\n    return c\n\ncount()\nprint(count())", check="out"),
```

#### Level 4: matching entries in `levels/l4.json`

```json
[
  {
    "id": "l4s1q1",
    "prompt": "Which word starts a function definition?",
    "options": [
      "def",
      "function",
      "func",
      "define"
    ],
    "correctIndex": 0,
    "explanation": "Python uses def. Other languages use words like function, which is why it's a common guess."
  },
  {
    "id": "l4s2q2",
    "prompt": "In def area(width, height):, what are width and height?",
    "options": [
      "Arguments",
      "Parameters",
      "Function names",
      "Function calls"
    ],
    "correctIndex": 1,
    "explanation": "The names in the def line are parameters. Arguments are the values you pass when calling, like area(3, 4). The function's name is area, and area(3, 4) is a call."
  },
  {
    "id": "l4s3q3",
    "prompt": "What does return do?",
    "options": [
      "Prints the value on the screen for the user",
      "Sends a value back to the code that called it and ends the function",
      "Runs the function again from the very top",
      "Saves the value so every function can use it"
    ],
    "correctIndex": 1,
    "explanation": "return gives a value back to the code that called the function, and the function stops there. Showing it on screen is print's job, and return does not repeat the function."
  },
  {
    "id": "l4s4q4",
    "prompt": "When is a default value used?",
    "options": [
      "When the caller doesn't pass a value for that parameter",
      "Always, even when the caller passes a different value",
      "Only when the function has no return line",
      "Only when the call uses keyword arguments"
    ],
    "correctIndex": 0,
    "explanation": "A passed value always replaces the default. The default only fills in when nothing is given, with or without keyword arguments."
  },
  {
    "id": "l4s5q1",
    "prompt": "What happens when this runs?",
    "options": [
      "It prints 5",
      "A NameError",
      "It prints None",
      "A TypeError"
    ],
    "correctIndex": 1,
    "explanation": "y is local to f and disappears when f ends, so print(y) can't find it and Python raises a NameError. Calling f() first doesn't make y available outside, so it does not print 5.",
    "code": "def f():\n    y = 5\n\nf()\nprint(y)"
  },
  {
    "id": "l4s5q4",
    "prompt": "What is a local variable?",
    "options": [
      "A variable that every function in the file can change",
      "A variable created at the top of the file, outside functions",
      "A variable made inside a function that exists only during the call",
      "A variable whose value can never be changed"
    ],
    "correctIndex": 2,
    "explanation": "Local means \"belongs to this function call\". A variable at the top of the file, outside all functions, is global."
  },
  {
    "id": "l4s5q6",
    "prompt": "Calling add(5) raises an error. What's the cleanest fix?",
    "options": [
      "Call add(5) twice so that total exists first",
      "Take total as a parameter and return total + n",
      "Delete the line total = 0 at the top of the file",
      "Add print(total) as the first line inside add"
    ],
    "correctIndex": 1,
    "explanation": "Assigning total inside the function makes it local, so total + n has nothing to read yet. Passing total in and returning the new value (total = add(total, 5)) avoids the problem. Calling twice, deleting the global or printing it first still leaves total local, so the error stays.",
    "code": "total = 0\n\ndef add(n):\n    total = total + n\n\nadd(5)"
  }
]
```

### Level 5

#### 5.1: `lesson("l5s1", ...)` quiz list, lines 1121-1132

```python
        # l5s1q1  (changed)
        m("Which line creates a list?", "nums = [1, 2, 3]", ['nums = "1, 2, 3"', 'nums = "[1, 2, 3]"', "nums == [1, 2, 3]"],
          "A list is written with square brackets and commas. Anything inside quotes is one string, even if it contains brackets, and == compares values instead of storing one."),
        # l5s1q2  (unchanged)
        m("What does this code print?", "3", ["27", "15", "2"],
          "len() counts items, not their total. There are 3 numbers in the list.",
          code_="nums = [4, 8, 15]\nprint(len(nums))", check="out"),
        # l5s1q3  (unchanged)
        m("What does this code print?", "False", ["True", "cow", "Error"],
          '"cow" is not one of the items, so in gives False. It\'s not an error to check for a missing value.',
          code_='pets = ["cat", "dog"]\nprint("cow" in pets)', check="out"),
        # l5s1q4  (unchanged)
        m("This list has 2 items, not 3. Why?", 'A comma is missing between "Asha" and "Ravi"',
          ["Lists can't hold names", "Lists need round brackets", "Strings in lists need single quotes"],
          'Without the comma Python joins the two strings into "AshaRavi". Both single and double quotes work in lists.',
          code_='names = ["Asha" "Ravi", "Meera"]'),
```

#### 5.2: `lesson("l5s2", ...)` quiz list, lines 1185-1203

```python
        # l5s2q1  (unchanged)
        m("What does this code print?", "green", ["red", "blue", "Error"],
          "Indexes start at 0, so x[1] is the second item. red would be x[0].",
          code_='x = ["red", "green", "blue"]\nprint(x[1])', check="out"),
        # l5s2q2  (unchanged)
        m("What does this code print?", "8", ["5", "7", "Error"],
          "-1 means the last item. Negative indexes are allowed, so there is no error.",
          code_="x = [5, 6, 7, 8]\nprint(x[-1])", check="out"),
        # l5s2q3  (unchanged)
        m("What does this code print?", "[2, 3, 4]", ["[1, 2, 3, 4]", "[2, 3, 4, 5]", "[1, 4]"],
          "x[1:4] starts at index 1 (the value 2) and stops before index 4, so the 5 at index 4 is left out.",
          code_="x = [1, 2, 3, 4, 5]\nprint(x[1:4])", check="out"),
        # l5s2q4  (changed)
        m("What happens when this runs?", "An IndexError",
          ["It prints book", "It prints pen", "A NameError"],
          "Two items means indexes 0 and 1, so items[2] goes past the end and Python raises an IndexError. book is items[1], the last item, and items does exist, so it is not a NameError.",
          code_='items = ["pen", "book"]\nprint(items[2])', check="err:IndexError"),
        # l5s2q5  (unchanged)
        m("Fill in the blank to get the first three items: nums[____]", ":3", ["1:3", "0:2", ":2"],
          "A slice stops before the stop index, so :3 gives indexes 0, 1, 2. 1:3 would skip the first item.",
          code_="nums = [4, 7, 1, 9, 3]\nfirst_three = nums[____]"),
        # l5s2q6  (unchanged)
        m("What does this code print?", "[9, 2, 3]", ["[1, 2, 3]", "[9, 1, 2, 3]", "[1, 9, 3]"],
          "a[0] = 9 replaces the first item. It doesn't insert a new one, so the list still has 3 items.",
          code_="a = [1, 2, 3]\na[0] = 9\nprint(a)", check="out"),
```

#### 5.3: `lesson("l5s3", ...)` quiz list, lines 1274-1289

```python
        # l5s3q1  (changed)
        m("What does this code print?", "[1, 2, 3]", ["[3, 1, 2]", "[1, 2]", "[3]"],
          "append() adds the value to the end of the list and keeps the items already there. It does not put 3 at the start or replace the list.",
          code_="a = [1, 2]\na.append(3)\nprint(a)", check="out"),
        # l5s3q2  (unchanged)
        m("What does this code print?", "[2, 5, 9]", ["[9, 5, 2]", "[5, 2, 9]", "None"],
          "sort() orders the list smallest first. Here the list is printed after sorting, so it isn't None.",
          code_="n = [5, 2, 9]\nn.sort()\nprint(n)", check="out"),
        # l5s3q3  (changed)
        m("What does pop() do?", "Removes the last item and returns it",
          ["Removes the first item and returns it", "Adds a new item at the end of the list", "Removes the last item and returns None"],
          "pop() takes the last item and hands it back, so you can store it. It doesn't take the first item, and unlike append() and sort() it does not give back None."),
        # l5s3q4  (changed)
        m("Why does this print None?", "sort() changes the list itself and returns None",
          ["Lists of numbers can't be sorted with sort()", "print can't show a list after sorting", "sort() only works if reverse=True is given"],
          "x = x.sort() stores sort()'s return value, which is None. Numbers sort fine and reverse=True is optional — just call x.sort() on its own line.",
          code_="x = [4, 1, 3]\nx = x.sort()\nprint(x)"),
        # l5s3q5  (changed)
        m("What does this code print?", "['a', 'b', 'c']", ["['b', 'c', 'a']", "['a', 'c']", "['b', 'a', 'c']"],
          "insert(0, \"a\") puts \"a\" at index 0, the front, and the other items move one place along. It does not add to the end like append(), and it does not replace \"b\".",
          code_='letters = ["b", "c"]\nletters.insert(0, "a")\nprint(letters)', check="out"),
```

#### 5.4: `lesson("l5s4", ...)` quiz list, lines 1324-1336

```python
        # l5s4q1  (unchanged)
        m("What does this code print?", "x\ny", ["['x', 'y']", "xy", "0\n1"],
          "The loop prints each item on its own line. It loops over the items, not their index numbers.",
          code_='for c in ["x", "y"]:\n    print(c)', check="out"),
        # l5s4q2  (unchanged)
        m("What does this code print?", "12", ["6", "246", "3"],
          "The numbers are added: 2 + 4 + 6 = 12. They are numbers, not strings, so they aren't joined into 246.",
          code_="total = 0\nfor n in [2, 4, 6]:\n    total += n\nprint(total)", check="out"),
        # l5s4q3  (unchanged)
        m("Which is a correct way to loop over the list names?", "for name in names:",
          ["for name in range(names):", "for names[] in name:", "for name of names:"],
          "Loop over the list directly. range() needs a number, so range(names) is a TypeError.",
          code_='names = ["Asha", "Ravi"]\n____\n    print(name)'),
        # l5s4q4  (unchanged)
        m("What does this code print?", "[5, 8]", ["[1]", "[1, 5, 8]", "2"],
          "Only numbers greater than 4 are appended. The new list is printed, not how many items it has.",
          code_="nums = [1, 5, 8]\nbig = []\nfor n in nums:\n    if n > 4:\n        big.append(n)\nprint(big)", check="out"),
```

#### 5.5: `lesson("l5s5", ...)` quiz list, lines 1385-1412

```python
        # l5s5q1  (unchanged)
        m("What does this code print?", "[0, 2, 4]", ["[2, 4, 6]", "[0, 1, 2]", "[0, 2, 4, 6]"],
          "range(3) gives 0, 1, 2, and each is doubled. It starts at 0, so the first value is 0, not 2.",
          code_="print([n * 2 for n in range(3)])", check="out"),
        # l5s5q2  (unchanged)
        m("What does this code print?", "[3, 4]", ["[1, 2]", "[2, 3, 4]", "[False, False, True, True]"],
          "Only items where x > 2 is True are kept, and the items themselves go in the list, not True/False.",
          code_="print([x for x in [1, 2, 3, 4] if x > 2])", check="out"),
        # l5s5q3  (changed)
        m('Which loop does [w + "s" for w in words] replace?',
          'A for loop that appends w + "s" to a new list',
          ['A for loop that prints w + "s" for each word', "A while loop that removes each w from words",
           'A for loop that adds "s" to the words list itself'],
          "A comprehension builds a brand-new list, like a loop that appends to an empty list. It doesn't print anything and doesn't change the original words list."),
        # l5s5q4  (changed)
        m("Find the bug.", "The value must come before for, with no colon",
          ["Comprehensions need round brackets ( )", "nums must be replaced by a range()", "The colon should be a semicolon ;"],
          "A comprehension is written [value for name in source], so the fix is [n * 2 for n in nums] with no colon. Square brackets are correct, and any list can be the source.",
          code_="doubled = [for n in nums: n * 2]"),
        # l5s5q5  (unchanged)
        m("What does this code print?", "['hihi', 'yoyo']", ["['hi', 'yo', 'hi', 'yo']", "hihiyoyo", "['hiyo']"],
          "Each word is joined with itself, giving one new item per word in a list.",
          code_='words = ["hi", "yo"]\nprint([w + w for w in words])', check="out"),
        # l5s5q6  (changed)
        m("Fill in the blank to keep only even numbers.", "if n % 2 == 0", ["if n % 2 == 1", "while n % 2 == 0", "for n % 2 == 0"],
          "A filter is an if at the end. n % 2 == 1 would keep the odd numbers instead, and while or for can't be used as a filter.",
          code_="evens = [n for n in nums ____]"),
        # l5s5q7  (unchanged)
        m("Which statement is true?", "A list comprehension always creates a new list",
          ["A list comprehension changes the original list", "A list comprehension can only use range()",
           "A list comprehension prints each item"],
          "The source list stays the same. You can loop over any list, not just range()."),
        # l5s5q8  (unchanged)
        m("What does this code print?", "[10, 30]", ["[10, 20, 30]", "[20]", "[1, 3]"],
          "2 is skipped by the filter, and the kept numbers are multiplied by 10.",
          code_="nums = [1, 2, 3]\nresult = [n * 10 for n in nums if n != 2]\nprint(result)", check="out"),
```

#### Level 5: matching entries in `levels/l5.json`

```json
[
  {
    "id": "l5s1q1",
    "prompt": "Which line creates a list?",
    "options": [
      "nums = \"1, 2, 3\"",
      "nums = [1, 2, 3]",
      "nums = \"[1, 2, 3]\"",
      "nums == [1, 2, 3]"
    ],
    "correctIndex": 1,
    "explanation": "A list is written with square brackets and commas. Anything inside quotes is one string, even if it contains brackets, and == compares values instead of storing one."
  },
  {
    "id": "l5s2q4",
    "prompt": "What happens when this runs?",
    "options": [
      "It prints book",
      "An IndexError",
      "It prints pen",
      "A NameError"
    ],
    "correctIndex": 1,
    "explanation": "Two items means indexes 0 and 1, so items[2] goes past the end and Python raises an IndexError. book is items[1], the last item, and items does exist, so it is not a NameError.",
    "code": "items = [\"pen\", \"book\"]\nprint(items[2])"
  },
  {
    "id": "l5s3q1",
    "prompt": "What does this code print?",
    "options": [
      "[1, 2, 3]",
      "[3, 1, 2]",
      "[1, 2]",
      "[3]"
    ],
    "correctIndex": 0,
    "explanation": "append() adds the value to the end of the list and keeps the items already there. It does not put 3 at the start or replace the list.",
    "code": "a = [1, 2]\na.append(3)\nprint(a)"
  },
  {
    "id": "l5s3q3",
    "prompt": "What does pop() do?",
    "options": [
      "Removes the first item and returns it",
      "Adds a new item at the end of the list",
      "Removes the last item and returns None",
      "Removes the last item and returns it"
    ],
    "correctIndex": 3,
    "explanation": "pop() takes the last item and hands it back, so you can store it. It doesn't take the first item, and unlike append() and sort() it does not give back None."
  },
  {
    "id": "l5s3q4",
    "prompt": "Why does this print None?",
    "options": [
      "sort() changes the list itself and returns None",
      "Lists of numbers can't be sorted with sort()",
      "print can't show a list after sorting",
      "sort() only works if reverse=True is given"
    ],
    "correctIndex": 0,
    "explanation": "x = x.sort() stores sort()'s return value, which is None. Numbers sort fine and reverse=True is optional — just call x.sort() on its own line.",
    "code": "x = [4, 1, 3]\nx = x.sort()\nprint(x)"
  },
  {
    "id": "l5s3q5",
    "prompt": "What does this code print?",
    "options": [
      "['b', 'c', 'a']",
      "['a', 'b', 'c']",
      "['a', 'c']",
      "['b', 'a', 'c']"
    ],
    "correctIndex": 1,
    "explanation": "insert(0, \"a\") puts \"a\" at index 0, the front, and the other items move one place along. It does not add to the end like append(), and it does not replace \"b\".",
    "code": "letters = [\"b\", \"c\"]\nletters.insert(0, \"a\")\nprint(letters)"
  },
  {
    "id": "l5s5q3",
    "prompt": "Which loop does [w + \"s\" for w in words] replace?",
    "options": [
      "A for loop that appends w + \"s\" to a new list",
      "A for loop that prints w + \"s\" for each word",
      "A while loop that removes each w from words",
      "A for loop that adds \"s\" to the words list itself"
    ],
    "correctIndex": 0,
    "explanation": "A comprehension builds a brand-new list, like a loop that appends to an empty list. It doesn't print anything and doesn't change the original words list."
  },
  {
    "id": "l5s5q4",
    "prompt": "Find the bug.",
    "options": [
      "Comprehensions need round brackets ( )",
      "nums must be replaced by a range()",
      "The colon should be a semicolon ;",
      "The value must come before for, with no colon"
    ],
    "correctIndex": 3,
    "explanation": "A comprehension is written [value for name in source], so the fix is [n * 2 for n in nums] with no colon. Square brackets are correct, and any list can be the source.",
    "code": "doubled = [for n in nums: n * 2]"
  },
  {
    "id": "l5s5q6",
    "prompt": "Fill in the blank to keep only even numbers.",
    "options": [
      "if n % 2 == 1",
      "if n % 2 == 0",
      "while n % 2 == 0",
      "for n % 2 == 0"
    ],
    "correctIndex": 1,
    "explanation": "A filter is an if at the end. n % 2 == 1 would keep the odd numbers instead, and while or for can't be used as a filter.",
    "code": "evens = [n for n in nums ____]"
  }
]
```

### Level 6

#### 6.2: `lesson("l6s2", ...)`

l6s2q5, question 5 in the list, line 1562:

```python
        m("Fill in the blank to show 2 decimal places.", ":.2f", [".2", ":2", ":2f"],
          ":.2f means 2 decimal places, so 12.3456 shows as 12.35. Without the dot, :2 only sets a width of 2 and shows 12.3456 unchanged, and :2f shows 12.345600, not 2 decimals. .2 without the colon is an error.",
          code_='total = 12.3456\nprint(f"{total____}")'),
```

#### 6.3: `lesson("l6s3", ...)`

l6s3q7, question 7 in the list, line 1650:

```python
        m("Fill in the blank to count words safely.", "get", ["count", "append", "values"],
          "get(word, 0) returns the current count, or 0 if the word is new, and then 1 is added. Dictionaries have no count() or append() method, and values() takes no word.",
          code_="counts[word] = counts.____(word, 0) + 1"),
```

#### 6.4: `lesson("l6s4", ...)`

l6s4q1, question 1 in the list, line 1715:

```python
        m("What does this code print?", "a\nb", ["1\n2", "a 1\nb 2", "a: 1\nb: 2"],
          "Looping over a dictionary gives its keys. To get values you need .values() or .items().",
          code_='d = {"a": 1, "b": 2}\nfor k in d:\n    print(k)', check="out"),
```

l6s4q2, question 2 in the list, line 1718:

```python
        m("What does this code print?", "x 3\ny 4", ["x\ny", "3\n4", "{'x': 3}\n{'y': 4}"],
          "items() gives each key with its value and the two variables take the pair apart, so print(k, v) shows the key and the value with a space. Only k would give x and y.",
          code_='d = {"x": 3, "y": 4}\nfor k, v in d.items():\n    print(k, v)', check="out"),
```

l6s4q4, question 4 in the list, line 1724:

```python
        m("What does .items() give you?", "Each key together with its value, as pairs",
          ["Only the values, one at a time", "Only the keys, in the order added", "The number of key-value pairs"],
          "items() gives key-value pairs. Only values is .values(), and the count is len(d)."),
```

#### Level 6: matching entries in `levels/l6.json`

```json
[
  {
    "id": "l6s2q5",
    "prompt": "Fill in the blank to show 2 decimal places.",
    "options": [
      ":.2f",
      ".2",
      ":2",
      ":2f"
    ],
    "correctIndex": 0,
    "explanation": ":.2f means 2 decimal places, so 12.3456 shows as 12.35. Without the dot, :2 only sets a width of 2 and shows 12.3456 unchanged, and :2f shows 12.345600, not 2 decimals. .2 without the colon is an error.",
    "code": "total = 12.3456\nprint(f\"{total____}\")"
  },
  {
    "id": "l6s3q7",
    "prompt": "Fill in the blank to count words safely.",
    "options": [
      "count",
      "append",
      "values",
      "get"
    ],
    "correctIndex": 3,
    "explanation": "get(word, 0) returns the current count, or 0 if the word is new, and then 1 is added. Dictionaries have no count() or append() method, and values() takes no word.",
    "code": "counts[word] = counts.____(word, 0) + 1"
  },
  {
    "id": "l6s4q1",
    "prompt": "What does this code print?",
    "options": [
      "a\nb",
      "1\n2",
      "a 1\nb 2",
      "a: 1\nb: 2"
    ],
    "correctIndex": 0,
    "explanation": "Looping over a dictionary gives its keys. To get values you need .values() or .items().",
    "code": "d = {\"a\": 1, \"b\": 2}\nfor k in d:\n    print(k)"
  },
  {
    "id": "l6s4q2",
    "prompt": "What does this code print?",
    "options": [
      "x\ny",
      "3\n4",
      "{'x': 3}\n{'y': 4}",
      "x 3\ny 4"
    ],
    "correctIndex": 3,
    "explanation": "items() gives each key with its value and the two variables take the pair apart, so print(k, v) shows the key and the value with a space. Only k would give x and y.",
    "code": "d = {\"x\": 3, \"y\": 4}\nfor k, v in d.items():\n    print(k, v)"
  },
  {
    "id": "l6s4q4",
    "prompt": "What does .items() give you?",
    "options": [
      "Only the values, one at a time",
      "Each key together with its value, as pairs",
      "Only the keys, in the order added",
      "The number of key-value pairs"
    ],
    "correctIndex": 1,
    "explanation": "items() gives key-value pairs. Only values is .values(), and the count is len(d)."
  }
]
```
## 5. Regenerating the course JSON

The attached level files were already regenerated with Python 3.11.15 and pass the script's validation, so **you don't need to run anything** if you commit them along with `build_course.py`. Also, your `build-pypath-apk.yml` already runs `python project/content/build_course.py` before every APK build, so the APK always gets fresh JSON.

If you ever edit `build_course.py` without regenerating, add this new file as `.github/workflows/regenerate-course.yml` (also attached). It doesn't touch `build-pypath-apk.yml` (your workflow is named `build-pypath-apk.yml`, not `build-apk.yml`, and is not modified).

```yaml
name: Regenerate course JSON

# Manual run: rebuilds the course JSON from PyPath/content/build_course.py
# and commits the changed files under PyPath/app/src/main/assets/course/.

on:
  workflow_dispatch:

permissions:
  contents: write

concurrency:
  group: regenerate-course
  cancel-in-progress: false

jobs:
  regenerate:
    runs-on: ubuntu-latest
    timeout-minutes: 10
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - uses: actions/setup-python@v5
        with:
          python-version: "3.11"

      - name: Build and validate course JSON
        working-directory: PyPath
        run: python content/build_course.py

      - name: Commit changed course JSON
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "41898282+github-actions[bot]@users.noreply.github.com"
          git add -A PyPath/app/src/main/assets/course
          git status --short
          if git diff --cached --quiet; then
            echo "Course JSON is already up to date."
          else
            git commit -m "Regenerate course JSON [bot]"
            git push
          fi
```

Workflow files have to be added through the GitHub web editor ("Add file" > "Create new file"). Your unzip workflow deliberately skips `.github/` inside zips.

### How to apply the update

Easiest: upload the attached `pypath-update.zip` to the repo and run your existing **Unzip PyPath update** workflow. The zip contains only `PyPath/content/build_course.py` and `PyPath/app/src/main/assets/course/levels/l1.json` ... `l6.json`, so it passes the workflow's protected-file check. The workflow then starts the APK build. You can also use the attached `quiz-audit.patch` (`git apply quiz-audit.patch`).

## 6. Final verification

All checks were run on the edited repo with Python 3.11.15:

- `python content/build_course.py` finished with "validation OK" (ids unique, 4 distinct options, valid correctIndex, every `check="out"` / `check="err:..."` question run and matched, Levels 3-6 balance rules, project/cheat-sheet/glossary checks).
- Question counts per sub-level are unchanged: 1.1-1.4: 4/4/4/4; 2.1-2.3: 3/3/3; Levels 3-6: [5, 6, 4, 8, 5, 3, 6, 4, 7, 4, 6, 5, 4, 8, 6, 5, 8, 6]. That's 125 questions in total, the same as before.
- Every question has exactly 4 distinct options and a correctIndex in 0-3. All 125 question ids are unique and unchanged, and they still follow the `<sub-level>q<n>` pattern that `CourseContentTest` checks.
- Correct-answer positions: Levels 3-6 are identical to before (no quiz has 3 in a row, and counts differ by at most 1). Levels 1-2 now have no quiz where one position holds more than half of the answers, and none with 3 in a row.
- Lesson pages, page counts, passPercent (60 everywhere), sub-level/level structure, ids and order are byte-for-byte identical. A comparison of every level JSON with the quizzes removed showed no differences. `course.json`, `glossary.json` and `l7.json` are identical to the originals.
- Files changed: only `PyPath/content/build_course.py` and `PyPath/app/src/main/assets/course/levels/l1.json` ... `l6.json`. Nothing in the Practical tab, Kotlin, Gradle, resources, androidTest or existing workflows was touched. The only new file is the optional `regenerate-course.yml`.
